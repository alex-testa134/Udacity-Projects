# Feed Reader

#Author: Alex Testa

## Table of Contents

* [Instructions](#instructions)
* [Contributing](#contributing)

## Update

This project was updated to ensure the testing using Jasmine was complete. Added tests to the feedreader.js file

to ensure no errors occur within the RSS feed. Multiple tests have been made and tested to ensure the program does what 

is intended. Additional tests may need to be added to ensure all parameters are accounted for.



